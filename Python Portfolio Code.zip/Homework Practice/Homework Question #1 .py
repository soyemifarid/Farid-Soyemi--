# write the number of male students in the class
males = int(input("enter number of males: "))
# enter the number of female students in the class
females = int(input("enter number of females: "))
# calculate total students
totalStudents = males+females
# calculate the percentage of males in the class
percentageOfMales = (males/totalStudents)*100
# calculate the number of female students in the class
percentageOfFemales = (females/totalStudents)*100
# print the percentage of of male students in the class
print("percentage of males is: %.2f%%" % percentageOfMales)
# print the percentage of female students in the class
print("percentage of females is: %.2f%%" % percentageOfFemales)
