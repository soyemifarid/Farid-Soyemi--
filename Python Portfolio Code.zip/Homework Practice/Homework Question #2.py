# enter the prices for the five entrees that were bought
itemOne = float(input("enter price for Item One: $"))
itemTwo = float(input("enter price for Item Two: $"))
itemThree = float(input("enter price for Item Three: $"))
itemFour = float(input("enter price for Item Four: $"))
itemFive = float(input("enter price for Item Five: $"))
# calculate the subtotal for the entrees
Subtotal = itemOne+itemTwo+itemThree+itemFour+itemFive
# print and round the subtotal for the entrees
print("Subtotal: $ %.2f" % Subtotal)
# calculate the tip amount
tip = (Subtotal*.18)
# round and print the tip amount to two decimal places
print("tip:$ %.2f" % tip)
# calculate the sales tax
salesTax = (Subtotal*.06)
# round and print the sales tax to two decimal places
print("Sales Tax: $ %.2f" % salesTax)
# calculate the grand total
grandTotal = (Subtotal+tip+salesTax)
# round and print the grand total
print("Grand total: $ %.2f" % grandTotal)
