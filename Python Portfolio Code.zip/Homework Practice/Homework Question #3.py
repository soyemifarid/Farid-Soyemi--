# enter the value of the two numbers
valueOne = int(input("Value One: "))
valueTwo = int(input("Value Two: "))
# calculate the sum of the two values
sum = (valueOne+valueTwo)
# print the sum of the two values
print("%-10s%5d" % ("sum:", sum))
# calculate the difference between the two values
difference = (valueOne-valueTwo)
# print the difference between the two values
print("%-10s%4d" % ("difference:", difference))
# calculate the product of the two values
product = (valueOne*valueTwo)
# print the product of the two values
print("%-10s%5d" % ("product:", product))
# calculate the average of the two values
average = (valueOne/valueTwo)
# print the average of the two values
print("%-10s%5d" % ("average:", average))
# calculate the absolute value of the difference
distance = abs(difference)
# print the distance
print("%-10s%5d" % ("dis:", distance))
# determine the  larger number between the two values
maximumNumber = max(valueOne, valueTwo)
# print the larger number
print("%-10s%5d" % ("max:", maximumNumber))
# determine the smaller number between the two values
minimumNumber = min(valueOne, valueTwo)
# print the smaller number
print("%-10s%5d" % ("min:", minimumNumber))
